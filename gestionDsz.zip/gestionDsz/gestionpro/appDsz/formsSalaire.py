from django import forms
from .models import Salaire

class SalaireForm(forms.ModelForm):
    class Meta:
        model = Salaire
        fields = ['employe', 'mois_paiement', 'montant_paiement', 'date_paiement', 'statut_paiement']
