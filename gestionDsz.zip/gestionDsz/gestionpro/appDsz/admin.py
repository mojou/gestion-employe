from django.contrib import admin
from .models import Employe,Salaire,Historique
# Register your models here.
admin.site.register(Employe)
admin.site.register(Salaire)
admin.site.register(Historique)