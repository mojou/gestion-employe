from django import forms
from .models import Employe

class EmployeForm(forms.ModelForm):
    class Meta:
        model = Employe
        fields = ['cni', 'nom', 'prénom', 'date_naiss', 'poste', 'salaire', 'date_embauche']
        widgets = {
            'date_naiss': forms.DateInput(attrs={'type': 'date'}),
            'date_embauche': forms.DateInput(attrs={'type': 'date'}),
            'salaire': forms.NumberInput(attrs={'step': '0.01'}),  # Pour les montants décimaux
        }
