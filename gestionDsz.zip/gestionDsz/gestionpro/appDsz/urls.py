from django.urls import path
from .views import ListEmployeClassView, CreateEmploye, DeleteEmploye, UpdateEmploye, ListSalaireClassView, CreateSalaire, UpdateSalaire, DeleteSalaire
from .views import HistoriqueListView

app_name = 'appDsz'
urlpatterns = [
    # ... autres URLS ...

    # Liste des employés
    path('employes/', ListEmployeClassView.as_view(), name='employes'),

    # Ajouter un employé
    path('employes/ajouter-employe/', CreateEmploye.as_view(), name='ajouter-employe'),

    # Supprimer un employé
    path('employes/delete-employe/<str:cni>/', DeleteEmploye.as_view(), name='delete-employe'),

    # Modifier un employé
    path('employes/update-employe/<str:cni>/', UpdateEmploye.as_view(), name='update-employe'),
    
    
    #les urls des salaires
    
    path('salaires/', ListSalaireClassView.as_view(), name='salaires'),
        
    # Ajouter un Salaire
    path('salaires/ajouter-salaire/', CreateSalaire.as_view(), name='ajouter-salaire'),

    # Supprimer un Salaire
    path('salaires/delete-salaire/<int:id>/', DeleteSalaire.as_view(), name='delete-salaire'),

    # Modifier un Salaire
    path('salaires/update-salaire/<int:id>/', UpdateSalaire.as_view(), name='update-salaire'),
    
        
        
# historiques
  # URL pour afficher l'historique d'un employé
   path('historiques/<str:employe_cni>/', HistoriqueListView.as_view(), name='historiques'),

]