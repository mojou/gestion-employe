from django.shortcuts import render#-
from django.core.paginator import Paginator
from .models import Employe,Salaire,Historique
from django.views.generic.edit import UpdateView#-
from django.views.generic import ListView#-
from django.views.generic.edit import CreateView #-
from django.views.generic.edit import DeleteView#-
from django.urls import reverse_lazy#+
from .forms import  EmployeForm
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


#cree la liste des employees
class ListEmployeClassView(ListView):
    model = Employe
    template_name = 'appDsz/list-employe.html'
    context_object_name = 'employes'
    
    def get_queryset(self):
        # Récupérer la requête de recherche dans la barre de recherche
        search_query = self.request.GET.get('search', '')  # Champ de recherche unique
        
        # Récupérer tous les employés par défaut
        queryset = Employe.objects.all()
        
        # Si une requête de recherche est fournie, filtrer les employés
        if search_query:
            queryset = queryset.filter(
                Q(nom__icontains=search_query) | Q(prénom__icontains=search_query)
            )  # Recherche par nom ou prénom
        
        return queryset

    
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Récupérer tous les objets employe
        employe_list = Employe.objects.all()

        # Effectuer la pagination
        paginator = Paginator(employe_list, 5)  # 1 salaire par page
        page = self.request.GET.get('page')  # Récupérer le numéro de page
        employes = paginator.get_page(page)  # Obtenir les objets de la page

        # Ajouter la pagination au contexte
        context['employes'] = employes
        return context
# cree un salaire des em
#cree un employe#-

class CreateEmploye(CreateView):#-
    model = Employe#-

    fields = ['cni','nom','prénom','date_naiss','poste','salaire','date_embauche']#-
    template_name = 'appDsz/ajouter-employe.html'#-
    success_url = reverse_lazy('appDsz:employes')  # Redirige vers la liste des employés après ajout
#-
    def form_valid(self, form):
        form.instance.user_name = self.request.user#-
        return super().form_valid(form)
    
# modifier un employe

class UpdateEmploye(UpdateView):
    model = Employe
    fields = ['nom', 'prénom', 'date_naiss', 'poste', 'salaire', 'date_embauche']  # Spécifiez les champs modifiables
    template_name = 'appDsz/update-employe.html'
    success_url = reverse_lazy('appDsz:employes')
    context_object_name = 'employes'
    pk_url_kwarg = 'cni'  
    # Utiliser 'cni' comme identifiant

  
class DeleteEmploye(DeleteView):
    model = Employe
    template_name = 'appDsz/delete-employe.html'
    success_url = reverse_lazy('appDsz:employes')

    # Le champ utilisé pour identifier l'employé (ici 'cni')
    slug_field = 'cni'
    slug_url_kwarg = 'cni'
    
    # traitement des salaire:
    
    
    # ajouter un salaire


#list des salaires

class ListSalaireClassView(ListView):
    model = Salaire
    template_name = 'appDsz/list-salaire.html'  # Chemin vers le template
    context_object_name = 'salaires'  # Nom du contexte utilisé dans le template
  
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Récupérer tous les objets Salaire
        salaires_list = Salaire.objects.all()

        # Effectuer la pagination
        paginator = Paginator(salaires_list, 5)  # 1 salaire par page
        page = self.request.GET.get('page')  # Récupérer le numéro de page
        salaires = paginator.get_page(page)  # Obtenir les objets de la page

        # Ajouter la pagination au contexte
        context['salaires'] = salaires
        return context
# cree un salaire des employees


class CreateSalaire(CreateView):
    model = Salaire
    fields = ['employe', 'mois_paiement', 'montant_paiement', 'date_paiement', 'statut_paiement']
    template_name = 'appDsz/ajouter-salaire.html'
    success_url = reverse_lazy('appDsz:salaires')  # Redirige vers la liste des salaires après ajout

    def form_valid(self, form):
        # Si vous voulez ajouter des actions supplémentaires avant de sauvegarder
        return super().form_valid(form)
    
class UpdateSalaire(UpdateView):
    model = Salaire
    fields = ['employe', 'mois_paiement', 'montant_paiement', 'date_paiement', 'statut_paiement']  # Spécifiez les champs modifiables
    template_name = 'appDsz/update-salaire.html'
    success_url = reverse_lazy('appDsz:salaires')
    context_object_name = 'salaire'
    pk_url_kwarg = 'id'  
    # Utiliser 'cni' comme identifiant
    
    
class DeleteSalaire(DeleteView):
    model = Salaire
    template_name = 'appDsz/delete-salaire.html'
    success_url = reverse_lazy('appDsz:salaires')

    # Le champ utilisé pour identifier l'employé (ici 'cni')
    slug_field = 'id'
    slug_url_kwarg = 'id'
        
        
# faire l'historiques



class HistoriqueListView(ListView):
    model = Historique
    template_name = 'appDsz/list-historique.html'
    context_object_name = 'historiques'

    def get_queryset(self):
        # Filtrer les historiques par employé (passé en paramètre dans l'URL)
        employe_cni = self.kwargs['employe_cni']
        return Historique.objects.filter(employe__cni=employe_cni).order_by('-date_paiement')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        employe_cni = self.kwargs['employe_cni']  # ici employe_cni correspond à cni dans l'URL
        
        # Utilisation de cni pour récupérer l'employé
        context['employe'] = Employe.objects.get(cni=employe_cni)  # Correction ici
        
        return context


        