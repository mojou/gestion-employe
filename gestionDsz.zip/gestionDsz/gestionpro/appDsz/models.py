from django.db import models
from django.utils import timezone
# Create your models here.
class Employe (models.Model):
    cni = models.CharField(max_length=20,primary_key=True)
    nom = models.CharField(max_length=200)
    prénom = models.CharField(max_length=200)
    date_naiss = models.DateField()
    poste = models.CharField(max_length=200)
    salaire = models.IntegerField()
    date_embauche = models.DateField()
    
    def __str__(self):
      return f'{self.prénom} {self.nom} (CNI: {self.cni})'  
  
  
  
class Salaire(models.Model):
    employe = models.ForeignKey(Employe, on_delete=models.CASCADE, related_name='salaires')  # Relation avec l'employé
    mois_paiement = models.DateField()  # Mois de paiement
    montant_paiement = models.IntegerField()  # Montant du paiement
    date_paiement = models.DateField()  # Date à laquelle le paiement est effectué
    statut_paiement = models.CharField(max_length=20, choices=[('En attente', 'En attente'), ('Réalisé', 'Réalisé'), ('Annulé', 'Annulé')], default='En attente')  # Statut du paiement

    def __str__(self):
        return f'Salaire de {self.employe.nom} pour {self.mois_paiement.strftime("%B %Y")}'


class Historique(models.Model):
    ACTION_CHOICES = [
        ('Ajout', 'Ajout'),
        ('Modification', 'Modification'),
        ('Suppression', 'Suppression'),
    ]

    employe = models.ForeignKey(Employe, on_delete=models.CASCADE, related_name='historiques')
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    date_paiement = models.DateTimeField(default=timezone.now)
    montant_paiement = models.IntegerField()  # Détails de l'action effectuée
    

    def __str__(self):
        return f"{self.get_action_display()} pour {self.employe.nom} le {self.date_action.strftime('%d/%m/%Y %H:%M:%S')}"
