from django.shortcuts import render, redirect
from django.contrib.auth import logout
#from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from .forms import RegisterForm
# Create your views here.

def index(request):
    # Ajoutez des données si nécessaire, sinon renvoyez juste le template.
    return render(request, 'index.html')

def register(request):
    # identifions quand le client clique sur le bouton
    if request.method == 'POST':
        # création d'un formulaire avec les données du formulaire
        form = RegisterForm(request.POST)
        # vérification des données
        if form.is_valid():
            form.save()  # Sauvegarde l'utilisateur dans la base de données
            username = form.cleaned_data.get('username')
            messages.success(request, f'Bienvenue {username}, votre compte a été créé avec succès !')
            #apres avoir cree un utilisateur rediriger vers login
            return redirect('login')
    else:
        form = RegisterForm()  # Si ce n'est pas un POST, un formulaire vide est affiché
    
    # Afficher le formulaire avec ou sans erreurs
    return render(request, 'user/register.html', {'form': form})




def LogoutView(request):
    # Déconnexion de l'utilisateur
    logout(request)
    
    # Ajouter un message de confirmation de déconnexion
    messages.success(request, "Vous avez été déconnecté avec succès.")
    
    # Redirection vers la page de connexion
    return redirect('login')  # Nom de l'URL de la page de connexion
